package ua.dima.shift;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.os.Build;
import android.os.SystemClock;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Bluetooth Low Energy — Vgate iCar Pro BLE, ELM327 BLE 4.0 тощо. */
@SuppressLint("MissingPermission")
class BleLink extends ObdLink {
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private final Context ctx;
    private final String addr;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic tx;
    private final StringBuilder buf = new StringBuilder();
    private final Object lock = new Object();
    private final CountDownLatch ready = new CountDownLatch(1);
    private volatile boolean ok, failed;

    BleLink(Context ctx, String addr) { this.ctx = ctx.getApplicationContext(); this.addr = addr; }

    private final BluetoothGattCallback cb = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                g.discoverServices();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                failed = true;
                ready.countDown();
                synchronized (lock) { lock.notifyAll(); }
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt g, int status) {
            for (BluetoothGattService s : g.getServices()) {
                BluetoothGattCharacteristic n = null, w = null;
                for (BluetoothGattCharacteristic c : s.getCharacteristics()) {
                    int p = c.getProperties();
                    if (n == null && (p & (BluetoothGattCharacteristic.PROPERTY_NOTIFY | BluetoothGattCharacteristic.PROPERTY_INDICATE)) != 0) n = c;
                    if (w == null && (p & (BluetoothGattCharacteristic.PROPERTY_WRITE | BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) != 0) w = c;
                }
                if (n != null && w != null) {
                    tx = w;
                    g.setCharacteristicNotification(n, true);
                    BluetoothGattDescriptor d = n.getDescriptor(CCCD);
                    if (d != null) {
                        boolean notify = (n.getProperties() & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0;
                        d.setValue(notify ? BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                                          : BluetoothGattDescriptor.ENABLE_INDICATION_VALUE);
                        if (g.writeDescriptor(d)) return;   // чекаємо onDescriptorWrite
                    }
                    ok = true;
                    ready.countDown();
                    return;
                }
            }
            failed = true;
            ready.countDown();
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor d, int status) {
            ok = true;
            ready.countDown();
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
            if (Build.VERSION.SDK_INT < 33) append(c.getValue());
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value) {
            append(value);
        }
    };

    private void append(byte[] v) {
        if (v == null) return;
        synchronized (lock) {
            buf.append(new String(v, StandardCharsets.US_ASCII));
            lock.notifyAll();
        }
    }

    @Override
    void open() throws IOException {
        BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
        if (ad == null || !ad.isEnabled()) throw new IOException("Bluetooth вимкнено");
        BluetoothDevice d = ad.getRemoteDevice(addr);
        gatt = d.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE);
        try {
            ready.await(15, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            throw new IOException("Перервано");
        }
        if (!ok || failed) throw new IOException("BLE-адаптер не відповідає");
    }

    @Override
    void write(byte[] data) throws IOException {
        if (gatt == null || tx == null || failed) throw new IOException("BLE відключено");
        boolean noResp = (tx.getProperties() & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0;
        tx.setWriteType(noResp ? BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                               : BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
        for (int i = 0; i < data.length; i += 20) {
            tx.setValue(Arrays.copyOfRange(data, i, Math.min(data.length, i + 20)));
            if (!gatt.writeCharacteristic(tx)) throw new IOException("Помилка запису BLE");
            if (data.length > 20) {
                try { Thread.sleep(30); } catch (InterruptedException e) { throw new IOException("Перервано"); }
            }
        }
    }

    @Override
    String readUntilPrompt(int timeoutMs) throws IOException {
        long end = SystemClock.uptimeMillis() + timeoutMs;
        synchronized (lock) {
            while (true) {
                int i = buf.indexOf(">");
                if (i >= 0) {
                    String r = buf.substring(0, i);
                    buf.delete(0, i + 1);
                    return r;
                }
                if (failed) throw new IOException("BLE відключено");
                long left = end - SystemClock.uptimeMillis();
                if (left <= 0) return "";
                try { lock.wait(left); } catch (InterruptedException e) { throw new IOException("Перервано"); }
            }
        }
    }

    @Override
    void clear() {
        synchronized (lock) { buf.setLength(0); }
    }

    @Override
    void close() {
        failed = true;
        try {
            if (gatt != null) { gatt.disconnect(); gatt.close(); }
        } catch (Exception ignored) { }
        gatt = null;
        synchronized (lock) { lock.notifyAll(); }
    }
}
