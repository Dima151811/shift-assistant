package ua.dima.shift;

import java.io.IOException;

/** Канал зв'язку з ELM327: звичайний Bluetooth або BLE. */
abstract class ObdLink {
    abstract void open() throws IOException;
    abstract void write(byte[] data) throws IOException;
    /** Читає відповідь до символу '>' (запрошення ELM327). Порожній рядок — тайм-аут. */
    abstract String readUntilPrompt(int timeoutMs) throws IOException;
    abstract void clear() throws IOException;
    abstract void close();
}
