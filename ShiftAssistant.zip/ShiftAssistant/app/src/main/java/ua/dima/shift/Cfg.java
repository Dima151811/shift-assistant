package ua.dima.shift;

import org.json.JSONArray;
import org.json.JSONObject;

/** Налаштування з інтерфейсу: межі обертів, звук, калібрування передач. */
final class Cfg {
    double up = 3000, max = 3300, low = 2000;
    boolean cold = true, sound = true;
    double[] ratios = {8.0, 14.5, 21.5, 28.5, 35.0};

    static Cfg parse(String json) {
        Cfg c = new Cfg();
        if (json == null) return c;
        try {
            JSONObject o = new JSONObject(json);
            c.up = o.optDouble("up", c.up);
            c.max = o.optDouble("max", c.max);
            c.low = o.optDouble("low", c.low);
            c.cold = o.optBoolean("cold", c.cold);
            c.sound = o.optBoolean("sound", c.sound);
            JSONArray a = o.optJSONArray("ratios");
            if (a != null && a.length() == 5) {
                double[] r = new double[5];
                for (int i = 0; i < 5; i++) r[i] = a.getDouble(i);
                c.ratios = r;
            }
        } catch (Exception ignored) { }
        return c;
    }
}
