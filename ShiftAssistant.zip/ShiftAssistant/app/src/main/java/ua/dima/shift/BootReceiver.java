package ua.dima.shift;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Запускає сервіс після ввімкнення магнітоли, якщо адаптер уже вибрано. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) return;
        if (c.getSharedPreferences(ObdService.PREFS, Context.MODE_PRIVATE).getString("addr", null) == null) return;
        try { ObdService.start(c); } catch (Exception ignored) { }
    }
}
