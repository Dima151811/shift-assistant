package ua.dima.shift;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.SystemClock;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

/** Звичайний Bluetooth (SPP) — більшість ELM327 mini. */
@SuppressLint("MissingPermission")
class ClassicLink extends ObdLink {
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private final String addr;
    private BluetoothSocket sock;
    private InputStream in;
    private OutputStream out;

    ClassicLink(String addr) { this.addr = addr; }

    @Override
    void open() throws IOException {
        BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
        if (ad == null || !ad.isEnabled()) throw new IOException("Bluetooth вимкнено");
        BluetoothDevice d = ad.getRemoteDevice(addr);
        try { ad.cancelDiscovery(); } catch (Exception ignored) { }
        try {
            sock = d.createRfcommSocketToServiceRecord(SPP);
            sock.connect();
        } catch (IOException e) {
            closeQuiet();
            sock = d.createInsecureRfcommSocketToServiceRecord(SPP);
            sock.connect();
        }
        in = sock.getInputStream();
        out = sock.getOutputStream();
    }

    @Override
    void write(byte[] data) throws IOException {
        out.write(data);
        out.flush();
    }

    @Override
    String readUntilPrompt(int timeoutMs) throws IOException {
        StringBuilder sb = new StringBuilder();
        long end = SystemClock.uptimeMillis() + timeoutMs;
        while (SystemClock.uptimeMillis() < end) {
            if (in.available() > 0) {
                int c = in.read();
                if (c < 0) throw new IOException("З'єднання закрито");
                if (c == '>') return sb.toString();
                sb.append((char) c);
            } else {
                try { Thread.sleep(10); } catch (InterruptedException e) { throw new IOException("Перервано"); }
            }
        }
        return "";   // тайм-аут
    }

    @Override
    void clear() throws IOException {
        while (in.available() > 0) in.read();
    }

    @Override
    void close() { closeQuiet(); }

    private void closeQuiet() {
        try { if (sock != null) sock.close(); } catch (IOException ignored) { }
    }
}
