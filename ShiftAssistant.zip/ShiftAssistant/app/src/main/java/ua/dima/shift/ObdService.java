package ua.dima.shift;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;

import org.json.JSONObject;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * Фоновий сервіс: тримає зв'язок з адаптером, опитує ЕБУ,
 * рахує мотогодини і подає звукові сигнали навіть коли екран зайнятий іншою програмою.
 */
public class ObdService extends Service {

    public interface Listener {
        void onData(String json);
        void onStatus(String text, String kind);
        void onLog(String line);
    }

    static final String PREFS = "shift";
    private static final String CHANNEL = "obd";
    private static final int NOTIF_ID = 1;

    static volatile Listener listener;
    static volatile ObdService instance;
    static volatile Cfg cfg;
    static volatile String lastStatus = "Не підключено";
    static volatile String lastKind = "";

    private SharedPreferences prefs;
    private volatile boolean running;
    private Thread worker;
    private volatile ObdLink link;
    private ToneGenerator tone;

    private volatile double rpm = -1, load = -1;
    private volatile int speed = -1, temp = -999;
    private volatile boolean connected;
    volatile long engineMs;
    private volatile long tripMs;
    private long lastTick, lastSave, lastDisconnect;
    private String lastState = "idle";

    // ---------- Керування ----------

    static void start(Context c) {
        Intent i = new Intent(c, ObdService.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
        else c.startService(i);
    }

    static void stop(Context c) {
        c.stopService(new Intent(c, ObdService.class));
    }

    static void setEngineMs(Context c, long ms) {
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putLong("engineMs", ms).apply();
        ObdService s = instance;
        if (s != null) s.engineMs = ms;
    }

    static long getEngineMs(Context c) {
        ObdService s = instance;
        return s != null ? s.engineMs : c.getSharedPreferences(PREFS, MODE_PRIVATE).getLong("engineMs", 0);
    }

    // ---------- Життєвий цикл ----------

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        engineMs = prefs.getLong("engineMs", 0);
        if (cfg == null) cfg = Cfg.parse(prefs.getString("cfg", null));
        try { tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 80); } catch (RuntimeException e) { tone = null; }

        createChannel();
        Notification n = buildNotification("Підключення…");
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
        else startForeground(NOTIF_ID, n);

        running = true;
        worker = new Thread(this::loop, "obd");
        worker.start();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        running = false;
        ObdLink l = link;
        if (l != null) l.close();
        if (worker != null) worker.interrupt();
        connected = false;
        saveHours();
        push();
        status("Не підключено", "");
        if (tone != null) tone.release();
        instance = null;
        super.onDestroy();
    }

    // ---------- Основний цикл ----------

    private void loop() {
        while (running) {
            String addr = prefs.getString("addr", null);
            String type = prefs.getString("type", "classic");
            if (addr == null) {
                status("Адаптер не вибрано", "");
                sleep(3000);
                continue;
            }
            try {
                status("Підключення…", "busy");
                ObdLink l = "ble".equals(type) ? new BleLink(this, addr) : new ClassicLink(addr);
                link = l;
                l.open();
                if (!running) break;
                initElm();
                if (SystemClock.elapsedRealtime() - lastDisconnect > 120_000) tripMs = 0;
                connected = true;
                status("Підключено: " + prefs.getString("name", "OBD"), "on");
                poll();
            } catch (Exception e) {
                if (running) log("Помилка: " + e.getMessage());
            } finally {
                ObdLink l = link;
                link = null;
                if (l != null) l.close();
                if (connected) lastDisconnect = SystemClock.elapsedRealtime();
                connected = false;
                rpm = -1; speed = -1; load = -1;
                lastTick = 0;
                saveHours();
                push();
            }
            if (running) {
                status("Немає зв'язку, повтор через 5 с", "");
                sleep(5000);
            }
        }
    }

    private void initElm() throws IOException {
        log("ATZ → " + cmd("ATZ", 3000).trim());
        for (String c : new String[]{"ATE0", "ATL0", "ATS0", "ATH0", "ATSP0"}) {
            log(c + " → " + cmd(c, 1500).trim());
        }
        String r = cmd("0100", 10000);
        log("0100 → " + r.trim());
        if (!r.replace(" ", "").toUpperCase(Locale.ROOT).contains("4100")) {
            throw new IOException("ЕБУ не відповідає — увімкніть запалювання");
        }
    }

    private void poll() throws IOException {
        int n = 0, fails = 0;
        while (running) {
            int[] a = parse(cmd("010C", 1500), "0C");
            if (a != null && a.length >= 2) {
                double raw = (a[0] * 256 + a[1]) / 4.0;
                rpm = rpm < 0 ? raw : rpm * 0.4 + raw * 0.6;
                fails = 0;
            } else if (++fails > 8) {
                throw new IOException("Адаптер перестав відповідати");
            }
            int[] s = parse(cmd("010D", 1500), "0D");
            if (s != null) speed = s[0];
            int[] l = parse(cmd("0104", 1500), "04");
            if (l != null) load = l[0] * 100.0 / 255;
            if (n % 25 == 0) {
                int[] t = parse(cmd("0105", 1500), "05");
                if (t != null) temp = t[0] - 40;
            }
            n++;
            tick();
            beeper();
            push();
        }
    }

    private String cmd(String c, int timeoutMs) throws IOException {
        ObdLink l = link;
        if (l == null) throw new IOException("Немає з'єднання");
        l.clear();
        l.write((c + "\r").getBytes(StandardCharsets.US_ASCII));
        return l.readUntilPrompt(timeoutMs);
    }

    static int[] parse(String resp, String pid) {
        String u = resp.toUpperCase(Locale.ROOT);
        if (u.contains("NO DATA") || u.contains("ERROR") || u.contains("UNABLE") || u.contains("STOPPED")) return null;
        String c = u.replace("SEARCHING...", "").replaceAll("[^0-9A-F]", "");
        int i = c.indexOf("41" + pid);
        if (i < 0) return null;
        String h = c.substring(i + 4);
        int n = Math.min(h.length() / 2, 4);
        if (n == 0) return null;
        int[] out = new int[n];
        for (int k = 0; k < n; k++) out[k] = Integer.parseInt(h.substring(k * 2, k * 2 + 2), 16);
        return out;
    }

    // ---------- Мотогодини ----------

    private void tick() {
        long now = SystemClock.elapsedRealtime();
        boolean on = rpm > 400;
        if (on && lastTick > 0) {
            long dt = Math.min(now - lastTick, 5000);   // захист від стрибків після паузи
            engineMs += dt;
            tripMs += dt;
            if (now - lastSave > 10_000) { saveHours(); lastSave = now; }
        }
        lastTick = on ? now : 0;
    }

    private void saveHours() {
        prefs.edit().putLong("engineMs", engineMs).apply();
    }

    // ---------- Звук ----------

    private void beeper() {
        Cfg c = cfg;
        if (c == null || tone == null) return;
        String st = state(c);
        if (!st.equals(lastState)) {
            if (c.sound) {
                if (st.equals("up") || st.equals("down")) tone.startTone(ToneGenerator.TONE_PROP_BEEP, 180);
                else if (st.equals("over")) tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 300);
            }
            lastState = st;
        }
    }

    private String state(Cfg c) {
        if (rpm < 0) return "idle";
        double up = c.up, max = c.max;
        if (c.cold && temp != -999 && temp < 70) { up = Math.min(up, 2500); max = Math.min(max, 2800); }
        if (rpm >= max) return "over";
        if (rpm >= up) return "up";
        int g = gear(c);
        if (speed >= 4 && g > 1 && rpm < c.low && load >= 45) return "down";
        return "ok";
    }

    private int gear(Cfg c) {
        if (speed < 4 || rpm < 600) return -1;
        double r = speed / rpm * 1000;
        int best = -1;
        double bd = Double.MAX_VALUE;
        for (int i = 0; i < c.ratios.length; i++) {
            double d = Math.abs(Math.log(r / c.ratios[i]));
            if (d < bd) { bd = d; best = i; }
        }
        return bd < 0.12 ? best + 1 : 0;
    }

    // ---------- Зв'язок з інтерфейсом ----------

    private void push() {
        Listener li = listener;
        if (li == null) return;
        try {
            JSONObject o = new JSONObject();
            o.put("connected", connected);
            o.put("rpm", rpm);
            o.put("speed", speed);
            o.put("load", load);
            o.put("temp", temp);
            o.put("engineSec", engineMs / 1000.0);
            o.put("tripSec", tripMs / 1000.0);
            li.onData(o.toString());
        } catch (Exception ignored) { }
    }

    private void status(String text, String kind) {
        lastStatus = text;
        lastKind = kind;
        Listener li = listener;
        if (li != null) li.onStatus(text, kind);
        if (running) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.notify(NOTIF_ID, buildNotification(text));
        }
    }

    private void log(String line) {
        Listener li = listener;
        if (li != null) li.onLog(line);
    }

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) { }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Підключення до OBD", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotification(String text) {
        Intent i = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        return b.setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("Передачі")
                .setContentText(text)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }
}
