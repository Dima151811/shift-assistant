package ua.dima.shift;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Показує інтерфейс (assets/index.html) і передає йому дані від ObdService. */
@SuppressLint("MissingPermission")
public class MainActivity extends Activity implements ObdService.Listener {

    private WebView web;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private BluetoothLeScanner scanner;
    private ScanCallback scanCb;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences(ObdService.PREFS, MODE_PRIVATE);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                onStatus(ObdService.lastStatus, ObdService.lastKind);
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");

        String[] missing = missingPermissions();
        if (missing.length > 0) requestPermissions(missing, 1);
        else if (prefs.getString("addr", null) != null) startServiceSafe();
    }

    @Override
    protected void onResume() {
        super.onResume();
        ObdService.listener = this;
        onStatus(ObdService.lastStatus, ObdService.lastKind);
    }

    @Override
    protected void onPause() {
        if (ObdService.listener == this) ObdService.listener = null;
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        stopScan();
        if (ObdService.listener == this) ObdService.listener = null;
        if (web != null) web.destroy();
        super.onDestroy();
    }

    // ---------- Дозволи ----------

    private String[] missingPermissions() {
        List<String> need = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 31) {
            need.add(Manifest.permission.BLUETOOTH_CONNECT);
            need.add(Manifest.permission.BLUETOOTH_SCAN);
        } else {
            need.add(Manifest.permission.ACCESS_FINE_LOCATION);   // потрібен для пошуку BLE до Android 12
        }
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS);
        List<String> miss = new ArrayList<>();
        for (String p : need) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) miss.add(p);
        }
        return miss.toArray(new String[0]);
    }

    private boolean bluetoothAllowed() {
        return Build.VERSION.SDK_INT < 31
                || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        if (bluetoothAllowed() && prefs.getString("addr", null) != null) startServiceSafe();
    }

    private void startServiceSafe() {
        if (!bluetoothAllowed()) { onLog("Немає дозволу на Bluetooth"); return; }
        try {
            ObdService.start(this);
        } catch (Exception e) {
            onLog("Не вдалося запустити сервіс: " + e.getMessage());
        }
    }

    // ---------- Дані від сервісу → JavaScript ----------

    private void js(String code) {
        if (web != null) web.evaluateJavascript(code, null);
    }

    @Override
    public void onData(String json) {
        ui.post(() -> js("window.onNative&&onNative(" + json + ")"));
    }

    @Override
    public void onStatus(String text, String kind) {
        ui.post(() -> js("window.onNativeStatus&&onNativeStatus(" + JSONObject.quote(text) + "," + JSONObject.quote(kind) + ")"));
    }

    @Override
    public void onLog(String line) {
        ui.post(() -> js("window.onNativeLog&&onNativeLog(" + JSONObject.quote(line) + ")"));
    }

    // ---------- Пошук BLE ----------

    private void startScan() {
        try {
            BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
            if (ad == null || !ad.isEnabled()) { onLog("Bluetooth вимкнено"); scanDone(); return; }
            scanner = ad.getBluetoothLeScanner();
            if (scanner == null) { scanDone(); return; }
            final Set<String> seen = new HashSet<>();
            scanCb = new ScanCallback() {
                @Override
                public void onScanResult(int type, ScanResult r) {
                    BluetoothDevice d = r.getDevice();
                    if (!seen.add(d.getAddress())) return;
                    String name = d.getName();
                    if (name == null && r.getScanRecord() != null) name = r.getScanRecord().getDeviceName();
                    if (name == null) return;   // безіменні пристрої не показуємо
                    try {
                        JSONObject o = new JSONObject();
                        o.put("name", name);
                        o.put("addr", d.getAddress());
                        o.put("type", "ble");
                        js("window.onNativeScan&&onNativeScan(" + o + ")");
                    } catch (Exception ignored) { }
                }

                @Override
                public void onScanFailed(int code) {
                    onLog("Пошук BLE не вдався, код " + code);
                    scanDone();
                }
            };
            scanner.startScan(scanCb);
            ui.postDelayed(this::stopScan, 10_000);
        } catch (Exception e) {
            onLog("Пошук BLE: " + e.getMessage());
            scanDone();
        }
    }

    private void stopScan() {
        try {
            if (scanner != null && scanCb != null) scanner.stopScan(scanCb);
        } catch (Exception ignored) { }
        if (scanCb != null) scanDone();
        scanCb = null;
    }

    private void scanDone() {
        js("window.onNativeScanDone&&onNativeScanDone()");
    }

    // ---------- Міст JavaScript → Java ----------

    class Bridge {
        /** Спарені Bluetooth-пристрої (сюди потрапляє ELM327 mini після спарювання в налаштуваннях). */
        @JavascriptInterface
        public String devices() {
            JSONArray arr = new JSONArray();
            try {
                BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
                if (ad == null) return "[]";
                for (BluetoothDevice d : ad.getBondedDevices()) {
                    JSONObject o = new JSONObject();
                    o.put("name", d.getName() == null ? d.getAddress() : d.getName());
                    o.put("addr", d.getAddress());
                    o.put("type", d.getType() == BluetoothDevice.DEVICE_TYPE_LE ? "ble" : "classic");
                    arr.put(o);
                }
            } catch (Exception e) {
                onLog("Список пристроїв: " + e.getMessage());
            }
            return arr.toString();
        }

        @JavascriptInterface
        public void scanBle() {
            ui.post(MainActivity.this::startScan);
        }

        @JavascriptInterface
        public void select(String addr, String type, String name) {
            prefs.edit().putString("addr", addr).putString("type", type).putString("name", name).apply();
            ui.post(() -> {
                stopScan();
                ObdService.stop(MainActivity.this);
                ui.postDelayed(MainActivity.this::startServiceSafe, 500);
            });
        }

        @JavascriptInterface
        public void forget() {
            prefs.edit().remove("addr").apply();
            ui.post(() -> ObdService.stop(MainActivity.this));
        }

        @JavascriptInterface
        public void config(String json) {
            prefs.edit().putString("cfg", json).apply();
            ObdService.cfg = Cfg.parse(json);
        }

        @JavascriptInterface
        public void setHours(double hours) {
            ObdService.setEngineMs(MainActivity.this, (long) (hours * 3_600_000));
        }

        @JavascriptInterface
        public double hours() {
            return ObdService.getEngineMs(MainActivity.this) / 3_600_000.0;
        }
    }
}
