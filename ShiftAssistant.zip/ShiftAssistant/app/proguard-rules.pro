# Методи, які викликає JavaScript, не можна перейменовувати
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
